# CSE 148 Baseline version 3.3

## Release v3.3 01/10/2024 Jiayan Dong: Adding support to generate benchmarks/hex files.

## Release v2.2 04/12/2018 Zinsser Zhang

Please refer to the wiki page **Walkthrough** for instructions to play around the design really quick.
Detailed documentations can be found in the wiki of this repository.
